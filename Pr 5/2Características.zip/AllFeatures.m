clear, clc, close all; 
load iris.mat;

%Barajar los datos. 
random = randperm(size(y,2));
x_rand = x(:,random);
y_rand = y(:,random);

%2 caracteristicas
comb = nchoosek(1:4,2)';
for k = 1:size(comb,2)
    combinacion = comb(:,k); %Recoges las caracteristicas que vas a tener en cuenta. 
    for j = 1:3 
        centroide(:,j) = kmeans(x_rand(combinacion, find(y == j-1)),1);
        dist(j,:) = d_euclid(x_rand(comb(:,k), :), centroide(:,j));
    end
    %Encontrar la distancia minima.
    [bas pos] = min(dist);
    tasa_acierto(2,k) = (sum(pos == (y_rand+1))/size(y_rand,2))*100; %Tasa de acierto aprox 90%
end




